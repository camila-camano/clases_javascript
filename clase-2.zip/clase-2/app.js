console.log("hola mundo");

alert("Simulador de promedios de 4 valores.");

let numero1 = parseInt(prompt("Inserte el primer valor:"));
let numero2 = parseInt(prompt("Inserte el segundo valor:"));
let numero3 = parseInt(prompt("Inserte el tercer valor:"));
let numero4 = parseInt(prompt("Inserte el cuarto valor:"));

const suma4 = (a, b, c, d) => a + b + c + d;
const promedio4 = (a, b, c, d) => suma4(a, b, c, d) / 4;

alert("El promedio es:" + " " + promedio4(numero1, numero2, numero3, numero4));
