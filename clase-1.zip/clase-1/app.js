console.log("hola mundo");
let numero1 = prompt("Inserte cualquier número del 1 al 100:");

if (numero1 > 100 || numero1 < 0) {
  alert("No está en el rango permitido!");
} else {
  let resto = numero1 % 2;

  if (resto == 0) {
    alert("Su número es par.");
  } else {
    alert("Su número es impar.");
  }
}
